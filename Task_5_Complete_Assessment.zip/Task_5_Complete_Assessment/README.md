# Task 5 — Python Lists, Tuples, Sets and Dictionaries

## Objective
Develop practical skills for handling structured data using Python collections.

## Deliverables
- Examples of all four collection types
- Programs demonstrating common methods
- Student and employee data processing
- Comparison table explaining differences
- Interview questions and answers

## Tools
Python, Jupyter Notebook
